import { Controller, Get, Param, Res, NotFoundException } from '@nestjs/common';
import { ApiTags, ApiOperation } from '@nestjs/swagger';
import { SkipThrottle } from '@nestjs/throttler';
import { Response } from 'express';
import { StorageService } from './storage.service';

@ApiTags('存储')
@Controller('storage')
export class StorageController {
  constructor(private readonly storageService: StorageService) {}

  /**
   * 静态访问已上传的对象，供前端 <img> 直接显示。
   * 路径形如 /storage/<bucket>/<key...>
   * 图片资源加载频繁，跳过全局限流。
   */
  @SkipThrottle()
  @Get(':bucket/*')
  @ApiOperation({ summary: '读取存储对象' })
  async getObject(
    @Param('bucket') bucket: string,
    @Param('0') key: string,
    @Res() res: Response,
  ) {
    try {
      const { stream, contentType } = await this.storageService.getObjectStream(bucket, key);
      res.setHeader('Content-Type', contentType);
      res.setHeader('Cache-Control', 'public, max-age=31536000, immutable');
      stream.pipe(res);
    } catch (error: any) {
      throw new NotFoundException('文件不存在');
    }
  }
}

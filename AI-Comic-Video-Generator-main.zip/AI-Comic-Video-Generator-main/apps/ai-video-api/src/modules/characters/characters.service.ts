import { Injectable, NotFoundException, BadRequestException, Logger } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';
import { AdapterFactory } from '../../common/adapters/adapter.factory';
import { StorageService } from '../storage/storage.service';
import { ModelsService } from '../models/models.service';
import { CreateCharacterDto } from './dto/create-character.dto';
import { UpdateCharacterDto } from './dto/update-character.dto';

@Injectable()
export class CharactersService {
  private readonly logger = new Logger(CharactersService.name);

  constructor(
    private readonly prisma: PrismaService,
    private readonly adapterFactory: AdapterFactory,
    private readonly storageService: StorageService,
    private readonly modelsService: ModelsService,
  ) {}

  async listByProject(userId: string, projectId: string) {
    await this.verifyProjectAccess(userId, projectId);
    const characters = await this.prisma.character.findMany({
      where: { projectId },
      orderBy: { createdAt: 'asc' },
    });
    return { data: characters };
  }

  async getOne(userId: string, projectId: string, characterId: string) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');
    return { data: character };
  }

  async create(userId: string, projectId: string, dto: CreateCharacterDto) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.create({
      data: {
        projectId,
        name: dto.name,
        gender: dto.gender,
        age: dto.age,
        role: dto.role,
        personality: dto.personality,
        appearance: dto.appearance,
        outfit: dto.outfit,
        lockLevel: dto.lockLevel || 'medium',
      },
    });
    return { data: character };
  }

  async update(userId: string, projectId: string, characterId: string, dto: UpdateCharacterDto) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');

    const updated = await this.prisma.character.update({
      where: { id: characterId },
      data: {
        ...(dto.name !== undefined && { name: dto.name }),
        ...(dto.gender !== undefined && { gender: dto.gender }),
        ...(dto.age !== undefined && { age: dto.age }),
        ...(dto.role !== undefined && { role: dto.role }),
        ...(dto.personality !== undefined && { personality: dto.personality }),
        ...(dto.appearance !== undefined && { appearance: dto.appearance }),
        ...(dto.outfit !== undefined && { outfit: dto.outfit }),
        ...(dto.lockLevel !== undefined && { lockLevel: dto.lockLevel }),
        ...(dto.prompt !== undefined && { prompt: dto.prompt }),
      },
    });
    return { data: updated };
  }

  async delete(userId: string, projectId: string, characterId: string) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');
    await this.prisma.character.delete({ where: { id: characterId } });
    return { success: true };
  }

  /**
   * 上传角色参考照片（存入 MinIO，记录到 character.referenceImage）
   */
  async uploadReferenceImage(userId: string, projectId: string, characterId: string, file: Express.Multer.File) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');
    if (!file) throw new BadRequestException('请上传照片文件');
    if (!file.mimetype?.startsWith('image/')) throw new BadRequestException('仅支持图片文件');

    const ext = (file.mimetype.split('/')[1] || 'png').replace('jpeg', 'jpg');
    const key = this.storageService.generateKey(projectId, `characters/${characterId}/reference`, undefined, ext);
    const url = await this.storageService.uploadBuffer(key, file.buffer, file.mimetype);

    const updated = await this.prisma.character.update({
      where: { id: characterId },
      data: { referenceImage: url },
    });

    this.logger.log(`Uploaded reference photo for character ${character.name}: ${url}`);
    return { data: { characterId, referenceImage: updated.referenceImage } };
  }

  /**
   * 读取角色参考照片的 base64（供图生图使用）。存储路径形如 /storage/<bucket>/<key>
   */
  private async loadReferenceBase64(referenceImage?: string | null): Promise<string | undefined> {
    if (!referenceImage) return undefined;
    const match = referenceImage.match(/^\/storage\/[^/]+\/(.+)$/);
    if (!match) return undefined;
    try {
      const { base64, contentType } = await this.storageService.getObjectBase64(match[1]);
      return `data:${contentType};base64,${base64}`;
    } catch (error: any) {
      this.logger.warn(`Failed to load reference image ${referenceImage}: ${error.message}`);
      return undefined;
    }
  }

  /**
   * 基于上传的照片生成角色主形象图
   */
  async generateFromPhoto(userId: string, projectId: string, characterId: string) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');
    if (!character.referenceImage) throw new BadRequestException('请先上传角色参考照片');

    const { apiKey, modelId, baseUrl } = await this.modelsService.resolveApiKey(userId, projectId, 'image');
    const imageAdapter = this.adapterFactory.getImageAdapter(modelId);
    const referenceImage = await this.loadReferenceBase64(character.referenceImage);

    const prompt = `${this.buildCharacterPrompt(character)}, character portrait, consistent with reference photo, high quality, clean background`;
    this.logger.log(`Generating main image from photo for character ${character.name}`);

    const result = await imageAdapter.generateImage(
      { prompt, width: 768, height: 768, referenceImage },
      { apiKey, baseUrl }
    );

    const updated = await this.prisma.character.update({
      where: { id: characterId },
      data: { mainImage: result.url },
    });

    return { data: { characterId, mainImage: updated.mainImage } };
  }

  /**
   * 生成角色四视图（正面/四分之三侧面/侧面/背面）
   */
  async generateViewImages(userId: string, projectId: string, characterId: string) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');

    const views = ['front', 'three_quarter', 'side', 'back'];
    const basePrompt = this.buildCharacterPrompt(character);

    this.logger.log(`Generating 4-view images for character ${character.name}`);

    // Resolve image model API key
    const { apiKey, modelId, baseUrl } = await this.modelsService.resolveApiKey(userId, projectId, 'image');

    const imageAdapter = this.adapterFactory.getImageAdapter(modelId);
    // 若角色已上传参考照片，则以其为参考图生成，保证形象一致
    const referenceImage = await this.loadReferenceBase64(character.referenceImage);
    const results: Record<string, string> = {};

    for (const view of views) {
      const viewPrompt = `${basePrompt}, ${this.getViewDescription(view)}, character design sheet, consistent style, clean background`;
      try {
        const result = await imageAdapter.generateImage(
          { prompt: viewPrompt, width: 768, height: 768, referenceImage },
          { apiKey, baseUrl }
        );
        results[view] = result.url;
        this.logger.log(`  ${view}: ${result.url}`);
      } catch (error: any) {
        this.logger.error(`Failed to generate ${view}: ${error.message}`);
        results[view] = '';
      }
    }

    const updated = await this.prisma.character.update({
      where: { id: characterId },
      data: { viewImages: results },
    });

    return { data: { characterId, viewImages: results } };
  }

  /**
   * 生成角色变体（表情/服装/场景）
   */
  async generateVariants(userId: string, projectId: string, characterId: string, variantType: string) {
    await this.verifyProjectAccess(userId, projectId);
    const character = await this.prisma.character.findFirst({
      where: { id: characterId, projectId },
    });
    if (!character) throw new NotFoundException('角色不存在');

    const basePrompt = this.buildCharacterPrompt(character);
    const variantPrompt = `${basePrompt}, ${this.getVariantDescription(variantType)}, character art, consistent style`;

    const { apiKey, modelId, baseUrl } = await this.modelsService.resolveApiKey(userId, projectId, 'image');
    const imageAdapter = this.adapterFactory.getImageAdapter(modelId);
    const referenceImage = await this.loadReferenceBase64(character.referenceImage);

    const result = await imageAdapter.generateImage(
      { prompt: variantPrompt, width: 768, height: 768, referenceImage },
      { apiKey, baseUrl }
    );

    // Append to existing variants
    const existingVariants = (character.variants as any[]) || [];
    const newVariant = { type: variantType, imageUrl: result.url, description: variantType, createdAt: new Date().toISOString() };
    const updatedVariants = [...existingVariants, newVariant];

    await this.prisma.character.update({
      where: { id: characterId },
      data: { variants: updatedVariants },
    });

    return { data: { characterId, variant: newVariant } };
  }

  /**
   * 构建角色描述提示词
   */
  buildCharacterPrompt(character: any): string {
    const parts: string[] = [];
    if (character.name) parts.push(character.name);
    if (character.gender) parts.push(character.gender);
    if (character.age) parts.push(`${character.age} years old`);
    if (character.appearance) parts.push(character.appearance);
    if (character.outfit) parts.push(`wearing ${character.outfit}`);
    if (character.personality) parts.push(character.personality);
    return parts.join(', ');
  }

  private getViewDescription(view: string): string {
    const map: Record<string, string> = {
      front: 'front view, facing camera, straight angle',
      three_quarter: 'three-quarter view, 45 degree angle, looking slightly left',
      side: 'side view, profile view, facing right',
      back: 'back view, facing away from camera',
    };
    return map[view] || view;
  }

  private getVariantDescription(type: string): string {
    const map: Record<string, string> = {
      happy: 'happy expression, smiling, cheerful',
      sad: 'sad expression, teary eyes, melancholic',
      angry: 'angry expression, fierce eyes, determined',
      surprised: 'surprised expression, wide eyes, open mouth',
      casual: 'casual clothes, relaxed outfit',
      formal: 'formal clothes, elegant outfit',
      school: 'school uniform, student outfit',
    };
    return map[type] || `${type} variant`;
  }

  private async verifyProjectAccess(userId: string, projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, userId },
    });
    if (!project) throw new NotFoundException('项目不存在');
  }
}

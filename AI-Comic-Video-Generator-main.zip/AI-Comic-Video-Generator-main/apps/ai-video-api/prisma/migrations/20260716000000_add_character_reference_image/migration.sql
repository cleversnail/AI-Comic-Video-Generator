-- AlterTable
ALTER TABLE `characters` ADD COLUMN `reference_image` VARCHAR(191) NULL;

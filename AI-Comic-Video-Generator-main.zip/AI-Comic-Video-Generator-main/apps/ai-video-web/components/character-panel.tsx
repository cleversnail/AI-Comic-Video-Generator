"use client";
import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { ImageIcon } from "@/components/icons";
import { charactersApi, resolveAssetUrl, Character } from "@/lib/api";

const viewLabels: Record<string, string> = {
  front: "正面",
  three_quarter: "四分之三侧",
  side: "侧面",
  back: "背面",
};

export function CharacterPanel({ projectId }: { projectId: string }) {
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [newName, setNewName] = useState("");

  const { data: characters = [] } = useQuery({
    queryKey: ["characters", projectId],
    queryFn: () => charactersApi.list(projectId),
  });

  const selected = characters.find((c) => c.id === selectedId) || null;
  const invalidate = () => queryClient.invalidateQueries({ queryKey: ["characters", projectId] });

  const createMutation = useMutation({
    mutationFn: (name: string) => charactersApi.create(projectId, { name }),
    onSuccess: (c) => { setNewName(""); setSelectedId(c.id); invalidate(); },
  });
  const deleteMutation = useMutation({
    mutationFn: (id: string) => charactersApi.delete(projectId, id),
    onSuccess: () => { setSelectedId(null); invalidate(); },
  });
  const uploadMutation = useMutation({
    mutationFn: ({ id, file }: { id: string; file: File }) => charactersApi.uploadPhoto(projectId, id, file),
    onSuccess: invalidate,
  });
  const fromPhotoMutation = useMutation({
    mutationFn: (id: string) => charactersApi.generateFromPhoto(projectId, id),
    onSuccess: invalidate,
  });
  const viewsMutation = useMutation({
    mutationFn: (id: string) => charactersApi.generateViews(projectId, id),
    onSuccess: invalidate,
  });
  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<Character> }) => charactersApi.update(projectId, id, data),
    onSuccess: invalidate,
  });

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file && selected) uploadMutation.mutate({ id: selected.id, file });
    e.target.value = "";
  };

  return (
    <div className="flex gap-6 h-full">
      {/* 角色列表 */}
      <div className="w-64 flex-shrink-0">
        <h2 className="font-display text-2xl font-bold text-white mb-1">角色</h2>
        <p className="text-text-secondary text-sm mb-4">{characters.length} 个角色</p>
        <div className="flex gap-2 mb-4">
          <Input
            placeholder="新角色名称..."
            value={newName}
            onChange={(e) => setNewName(e.target.value)}
            onKeyDown={(e) => { if (e.key === "Enter" && newName.trim()) createMutation.mutate(newName.trim()); }}
          />
          <Button size="sm" disabled={!newName.trim()} isLoading={createMutation.isPending} onClick={() => createMutation.mutate(newName.trim())}>添加</Button>
        </div>
        <div className="space-y-2">
          {characters.map((c) => (
            <motion.button
              key={c.id}
              layout
              onClick={() => setSelectedId(c.id)}
              className={`w-full flex items-center gap-3 p-2 rounded-xl border-2 transition-colors text-left ${selectedId === c.id ? "border-anime-purple bg-anime-purple/10" : "border-divider hover:border-anime-purple/50 bg-panel-mid"}`}
            >
              <div className="w-12 h-12 rounded-lg overflow-hidden bg-panel-deep flex items-center justify-center flex-shrink-0">
                {c.mainImage || c.referenceImage
                  ? <img src={resolveAssetUrl(c.mainImage || c.referenceImage)} alt={c.name} className="w-full h-full object-cover" />
                  : <ImageIcon className="w-5 h-5 text-text-disabled" />}
              </div>
              <div className="min-w-0">
                <p className="text-sm font-medium text-white truncate">{c.name}</p>
                <p className="text-xs text-text-disabled truncate">{c.role || c.appearance || "未设定"}</p>
              </div>
            </motion.button>
          ))}
        </div>
      </div>

      {/* 角色详情 */}
      {selected ? (
        <div className="flex-1 border-l border-divider pl-6 overflow-auto">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-display text-lg font-semibold text-white">{selected.name}</h3>
            <button onClick={() => { if (confirm("确认删除此角色？")) deleteMutation.mutate(selected.id); }} className="text-xs text-warm-orange hover:underline">删除</button>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* 上传照片 + 生成形象 */}
            <div>
              <label className="block text-sm text-text-secondary mb-2">参考照片</label>
              <div className="aspect-square rounded-xl border-2 border-dashed border-divider bg-panel-mid flex items-center justify-center overflow-hidden mb-3">
                {selected.referenceImage
                  ? <img src={resolveAssetUrl(selected.referenceImage)} alt="reference" className="w-full h-full object-cover" />
                  : <div className="text-center text-text-disabled text-sm px-4"><ImageIcon className="w-8 h-8 mx-auto mb-2" />上传一张照片<br />作为角色形象参考</div>}
              </div>
              <input ref={fileInputRef} type="file" accept="image/*" className="hidden" onChange={handleFile} />
              <div className="flex gap-2">
                <Button variant="outline" size="sm" className="flex-1" isLoading={uploadMutation.isPending} onClick={() => fileInputRef.current?.click()}>
                  {selected.referenceImage ? "更换照片" : "上传照片"}
                </Button>
                <Button
                  size="sm"
                  className="flex-1"
                  disabled={!selected.referenceImage}
                  isLoading={fromPhotoMutation.isPending}
                  onClick={() => fromPhotoMutation.mutate(selected.id)}
                >
                  生成形象
                </Button>
              </div>
              {fromPhotoMutation.isError && <p className="text-xs text-warm-orange mt-2">生成失败，请检查图像模型 API Key 是否已配置</p>}
            </div>

            {/* 生成结果 */}
            <div>
              <label className="block text-sm text-text-secondary mb-2">生成形象</label>
              <div className="aspect-square rounded-xl border border-divider bg-panel-mid flex items-center justify-center overflow-hidden">
                {fromPhotoMutation.isPending || viewsMutation.isPending
                  ? <div className="w-8 h-8 rounded-full border-2 border-anime-purple border-t-transparent animate-spin" />
                  : selected.mainImage
                    ? <img src={resolveAssetUrl(selected.mainImage)} alt="main" className="w-full h-full object-cover" />
                    : <ImageIcon className="w-10 h-10 text-text-disabled" />}
              </div>
              <Button variant="outline" size="sm" className="w-full mt-3" isLoading={viewsMutation.isPending} onClick={() => viewsMutation.mutate(selected.id)}>
                生成四视图
              </Button>
            </div>
          </div>

          {/* 四视图 */}
          {selected.viewImages && Object.keys(selected.viewImages).length > 0 && (
            <div className="mt-6">
              <label className="block text-sm text-text-secondary mb-2">角色四视图</label>
              <div className="grid grid-cols-4 gap-3">
                {["front", "three_quarter", "side", "back"].map((v) => (
                  <div key={v}>
                    <div className="aspect-square rounded-lg bg-panel-mid border border-divider overflow-hidden flex items-center justify-center">
                      {selected.viewImages?.[v]
                        ? <img src={resolveAssetUrl(selected.viewImages[v])} alt={v} className="w-full h-full object-cover" />
                        : <ImageIcon className="w-5 h-5 text-text-disabled" />}
                    </div>
                    <p className="text-xs text-text-secondary text-center mt-1">{viewLabels[v]}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* 基础信息 */}
          <div className="mt-6 space-y-3">
            <label className="block text-sm text-text-secondary">基础信息</label>
            <div className="grid grid-cols-2 gap-3">
              <Input placeholder="性别" defaultValue={selected.gender || ""} onBlur={(e) => e.target.value !== (selected.gender || "") && updateMutation.mutate({ id: selected.id, data: { gender: e.target.value } })} />
              <Input placeholder="角色定位（如：主角）" defaultValue={selected.role || ""} onBlur={(e) => e.target.value !== (selected.role || "") && updateMutation.mutate({ id: selected.id, data: { role: e.target.value } })} />
            </div>
            <Textarea placeholder="外貌描述" defaultValue={selected.appearance || ""} className="text-sm" onBlur={(e) => e.target.value !== (selected.appearance || "") && updateMutation.mutate({ id: selected.id, data: { appearance: e.target.value } })} />
            <Textarea placeholder="服装描述" defaultValue={selected.outfit || ""} className="text-sm" onBlur={(e) => e.target.value !== (selected.outfit || "") && updateMutation.mutate({ id: selected.id, data: { outfit: e.target.value } })} />
          </div>
        </div>
      ) : (
        <div className="flex-1 flex items-center justify-center text-text-disabled">
          <div className="text-center">
            <ImageIcon className="w-12 h-12 mx-auto mb-3" />
            <p>选择或创建一个角色</p>
          </div>
        </div>
      )}
    </div>
  );
}

# 功能：上传照片生成角色形象

基于用户上传的真实照片，通过可灵（Kling）image-to-image 生成分镜角色形象/四视图，保证角色一致性。

## 决策
- 前端：在工作台新增完整「角色」面板（列表 + 创建/编辑 + 上传照片 + 生成形象/四视图）
- 参考图模型：可灵 Kling（接通 image-to-image）
- 存储：MinIO + 预签名 URL（外部 Kling 调用时用 base64 传参）

---

## 后端改动 (apps/ai-video-api)

### 1. 数据模型 (prisma/schema.prisma)
`Character` 模型新增字段：
- `referenceImage String? @map("reference_image")` — 用户上传的原始照片 URL（MinIO key/路径）
- 复用已有 `mainImage`（生成结果主图）、`viewImages`、`variants`

执行 `npx prisma migrate dev --name add_character_reference_image`（若环境无 DB，则改用 `prisma db push` 或说明手动迁移）。

### 2. StorageService 增强 (modules/storage/storage.service.ts)
- 新增 `getObjectBase64(key): Promise<{ base64: string; contentType: string }>`：从 MinIO 读取对象转 base64，供 Kling image-to-image 使用。
- `uploadBuffer` 返回的路径已是 `/storage/<bucket>/<key>`，保留。

### 3. 静态访问路由（让前端能显示上传图）
`main.ts` 目前未挂载 `/storage` 静态服务。新增一个 `StorageController`（`@Controller('storage')`）提供 `GET /storage/:bucket/*` → 通过 MinIO 流式返回对象，供前端 `<img>` 显示。（避免依赖 MinIO 直连端口。）

### 4. Kling image-to-image 接通 (modules/models/adapters/kling-image.adapter.ts)
- `generateImage` 支持 `input.referenceImage`：当存在时，在请求体加入
  - `image`: base64（去掉 data 前缀）
  - `image_reference`: `'subject'`（角色主体参考，保证一致性）
  - `image_fidelity`: 0.5（可调）
- Flux 保持不变（本次不接）。

### 5. CharactersService (modules/characters/characters.service.ts)
- **修复现有 Bug**：`resolveImageKey` 返回空 apiKey，替换为注入 `ModelsService` 并调用 `modelsService.resolveApiKey(userId, projectId, 'image')`（与 keyframe.service 一致）。删除坏的 `resolveImageKey`。
- 新增 `uploadReferenceImage(userId, projectId, characterId, file)`：
  - 校验项目/角色归属
  - `storageService.uploadBuffer(key, file.buffer, mimetype)` 存原图
  - 更新 `character.referenceImage`
  - 返回可访问 URL
- 改造 `generateViewImages` / `generateVariants`：当角色有 `referenceImage` 时，读取其 base64 并作为 `referenceImage` 传入 `imageAdapter.generateImage`，实现「照 photo 生成」。无照片时退回纯文本生成（保持原行为）。
- 新增 `generateFromPhoto(...)`（可选，单独入口）：基于上传照片直接生成主形象图 `mainImage`。

### 6. CharactersController (modules/characters/characters.controller.ts)
新增端点：
- `POST /projects/:projectId/characters/:characterId/upload-photo`（`FileInterceptor('file')`，参考 script-import.controller 写法）→ 上传照片
- 生成端点复用现有 `generate-views` / `variants`（内部自动用照片）
- 可选：`POST /projects/:projectId/characters/:characterId/generate-from-photo`

### 7. Module (characters.module.ts)
- 已 import `ModelsModule`（含 ModelsService）与 `StorageModule`，确认可注入。

---

## 前端改动 (apps/ai-video-web)

### 1. API 层 (lib/api.ts)
新增 `Character` 类型与 `charactersApi`：
- `list / create / update / delete / getOne`
- `uploadPhoto(projectId, characterId, file)` → `FormData` POST
- `generateViews(projectId, characterId)`
- `generateVariant(projectId, characterId, type)`

### 2. 工作台新增「角色」Tab (studio/page.tsx)
- `tabs` 增加 `{ id: "character", label: "角色" }`
- 新组件 `CharacterPanel`（放 `components/` 或 page 内）：
  - 左侧角色卡片列表（显示 mainImage/referenceImage 缩略图）
  - 右侧详情：基础信息表单（name/gender/age/appearance/outfit…）
  - **上传照片区**：文件选择 → 预览 → 上传（调 uploadPhoto）
  - 「基于照片生成形象」「生成四视图」按钮 → 生成后展示结果图
  - React Query mutation + invalidate，风格沿用现有暗色 UI（anime-purple 等）

---

## Git 提交（按 CLAUDE.md 规范，分模块提交）
1. `feat: characters: 新增 referenceImage 字段与 Prisma migration`
2. `feat: storage: 新增对象 base64 读取与静态访问路由`
3. `feat: kling: 接通 image-to-image 参考图生成`
4. `feat: characters: 上传照片 + 基于照片生成形象 API（并修复 apiKey 解析）`
5. `feat: web: 工作台角色面板与照片上传生成 UI`

## 待确认/风险
- 无本地 DB 时 migration 可能无法执行 → 会改用 `db push` 或提示手动执行。
- Kling `image_reference`/`image_fidelity` 参数名以其官方文档为准（网络受限未能在线核对），如实际字段不同将按报错调整。
